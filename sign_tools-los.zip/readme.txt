1.将需要签名的apk 拷贝到Source Apk
2.双击执行 sign-OdmSzTools.bat
3.SingedApk目录生成LineageOS 签名过的OdmSzTools.apk

注：
Android 11 编译framework命令：  make framework-minus-apex
生成
LineageOS/out/target/common/obj/JAVA_LIBRARIES/framework-minus-apex_intermediates/classes.jar

重命名为fwk-los.jar